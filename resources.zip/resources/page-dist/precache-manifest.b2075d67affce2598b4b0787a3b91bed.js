self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "50d2f4d972d97d317d703c75da17ee5c",
    "url": "./index.html"
  },
  {
    "revision": "c9899c8dd9df031a2e64",
    "url": "./static/css/LicenseIndex.180dd4c7.c9ec71e6.chunk.css"
  },
  {
    "revision": "31dcf5fd9a513024f0cd",
    "url": "./static/css/Preferences.962926a4.661f08b3.chunk.css"
  },
  {
    "revision": "e66c03f4e71d8635033b",
    "url": "./static/css/WelcomeIndex.63db304f.db2de154.chunk.css"
  },
  {
    "revision": "5a1f14baa0063a662b5c",
    "url": "./static/css/localSettingIndex.a2c75cbd.4f5879ee.chunk.css"
  },
  {
    "revision": "5c9f8490f969c26913bf",
    "url": "./static/js/0.99879679.chunk.js"
  },
  {
    "revision": "8b32dc95a2ee91e1b5d7d27e55fe304c",
    "url": "./static/js/0.99879679.chunk.js.LICENSE.txt"
  },
  {
    "revision": "02fc3dfcb9c59b585c6b",
    "url": "./static/js/1.a0005c60.chunk.js"
  },
  {
    "revision": "1a86f6656a2caa77b411",
    "url": "./static/js/12.41027302.chunk.js"
  },
  {
    "revision": "5735008847451525374b1f222e4ab316",
    "url": "./static/js/12.41027302.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c9899c8dd9df031a2e64",
    "url": "./static/js/LicenseIndex.180dd4c7.4da8909c.chunk.js"
  },
  {
    "revision": "31dcf5fd9a513024f0cd",
    "url": "./static/js/Preferences.962926a4.bc0c6841.chunk.js"
  },
  {
    "revision": "e66c03f4e71d8635033b",
    "url": "./static/js/WelcomeIndex.63db304f.9d9e058b.chunk.js"
  },
  {
    "revision": "5a1f14baa0063a662b5c",
    "url": "./static/js/localSettingIndex.a2c75cbd.6a74b309.chunk.js"
  },
  {
    "revision": "ea0cdf525dc17ab2d173",
    "url": "./static/js/main.ff8bdafd.chunk.js"
  },
  {
    "revision": "32af8fee8c88440a3a0c",
    "url": "./static/js/runtime-LicenseIndex.180dd4c7.f7c007dd.js"
  },
  {
    "revision": "31eade27ad84fcd5e43c",
    "url": "./static/js/runtime-Preferences.962926a4.285eabb5.js"
  },
  {
    "revision": "68fdb37641c2c95f87f3",
    "url": "./static/js/runtime-WelcomeIndex.63db304f.ab2b23b4.js"
  },
  {
    "revision": "02c80b5dbf4b0857413b",
    "url": "./static/js/runtime-localSettingIndex.a2c75cbd.6f0fb930.js"
  },
  {
    "revision": "a58e29c10aa59053062a",
    "url": "./static/js/runtime-main.97d0b459.js"
  },
  {
    "revision": "06a6aa233c23b10f45b5ec4a8924866b",
    "url": "./static/media/icon.06a6aa23.png"
  },
  {
    "revision": "1382c29cdb72f6c99043675d6e13b625",
    "url": "./static/media/photon-entypo.1382c29c.ttf"
  },
  {
    "revision": "2614e058b2dcb9d6e2e964730d795540",
    "url": "./static/media/photon-entypo.2614e058.eot"
  },
  {
    "revision": "bf614256dbc49f4bf2cf786706bb0712",
    "url": "./static/media/photon-entypo.bf614256.woff"
  }
]);